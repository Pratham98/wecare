package com.wecare.controller;

import java.time.LocalDate;
import java.util.List;

import javax.ws.rs.DELETE;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.wecare.DTO.AppointDTO;
import com.wecare.DTO.BookDTO;
import com.wecare.DTO.CoachDTO;
import com.wecare.DTO.LoginDTO;
import com.wecare.DTO.UserDTO;
import com.wecare.service.BookService;



@RestController
@CrossOrigin
public class BookController {
	
	
	Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	BookService bookService ;
	@Autowired
	RestTemplate template;
	
	@PostMapping(value = "/booking/users/{userId}/booking/{coachId}",  consumes = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Boolean> bookAppointment(@PathVariable("userId")Integer userId,@PathVariable("coachId") Integer coachId,@RequestBody AppointDTO appointDTO) {
		@SuppressWarnings("unchecked")
		UserDTO tdto= template.getForObject("http://USERMS/users/"+userId, UserDTO.class);
		System.out.println(tdto);
		if(tdto==null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(false);
		}
		CoachDTO cdto= template.getForObject("http://COACHMS/coaches/"+coachId, CoachDTO.class);
		System.out.println(cdto);
		if(cdto==null) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(false);
		}
		return ResponseEntity.ok(bookService.bookAppointment(userId,coachId,appointDTO));
	}
	@GetMapping(value = "/booking/coaches/{coachId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<BookDTO>> getCoachBook(@PathVariable("coachId") Integer id){
		List<BookDTO> bookDTO=bookService.getCoachBook(id);
		return ResponseEntity.ok(bookDTO);
	}
	@GetMapping(value = "/booking/users/{userId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<BookDTO>> getUserBook(@PathVariable("userId") Integer id){
		List<BookDTO> bookDTO=bookService.getUserBook(id);
		return ResponseEntity.ok(bookDTO);
	}
	
}

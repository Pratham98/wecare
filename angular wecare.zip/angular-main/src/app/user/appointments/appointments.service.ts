import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AppointmentsService {

  constructor(private http:HttpClient) {}

  schedules():Observable<any[]>{

    return this.http.get<any[]>("http://localhost:8080/bookings");
  }

  confirmAppointment(obj:any):Observable<any>{
    return this.http.post("http://localhost:8080/bookings",obj)
  }

  deleteAppointment(obj:any):Observable<unknown>{
    return this.http.delete<void>("http://localhost:8080/bookings/obj")
  }

  updateAppointment(obj:any):Observable<unknown>{
    return this.http.put<void>("http://localhost:8080/bookings/obj",obj)
  }
}

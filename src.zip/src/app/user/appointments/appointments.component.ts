import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { AppointmentsService } from './appointments.service';
import constant from '../../../assets/constant';

@Component({
  selector: 'app-appointments',
  templateUrl: './appointments.component.html',
  styleUrls: ['./appointments.component.css']
})
export class AppointmentsComponent implements OnInit {
  readonly CONSTANT = constant;
  coachDetail!:any[]
  selectedId!:number;
  book!:boolean;
  bookForm!:FormGroup;
  success!:boolean;
  id!:number;
  popup!:boolean;
  schedulesDetail!:any[]
  constructor(private appointmentsService:AppointmentsService,private formBuilder :FormBuilder) {  }
 ngOnInit(){
  this.bookForm=this.formBuilder.group({
    appointmentDate: ['',[Validators.required,dateCalculator]],
    slot :['',[Validators.required]]
    })

  this.id=parseInt(sessionStorage.getItem("loggedUser") || '0');
  this.schedules();
 }

 onClick(id:number){
  this.book=true;
  this.selectedId=id;
}
refresh(){
  window.location.reload();
}

updateAppointment(){
  var index = this.schedulesDetail.findIndex((x: { id: string; }) => x.id ==""+this.selectedId);
  var obj={appointmentDate:this.bookForm.controls["appointmentDate"].value,slot:this.bookForm.controls["slot"].value,userId:''+this.id,coachId:''+this.schedulesDetail[index].coachId}
  this.appointmentsService.updateAppointment(obj,this.selectedId).subscribe(res=>{this.success=true;this.book=false;});

}

 schedules(){
  this.schedulesDetail=[]
  this.appointmentsService.schedules().subscribe(res=>{
    for(const obj of res){
      if(this.id==getId(obj)){
        this.schedulesDetail.push(obj);
      }
    }
    console.log(this.schedulesDetail);
  }
  );
}

deleteAppointment(){

  // this.schedulesDetail.splice(index, 1);
  this.appointmentsService.deleteAppointment(this.selectedId).
  subscribe(res=>{this.success=false;this.book=false;window.location.reload();});
}

}

function getId(res:any):any{
let id;
for (const [key, value] of Object.entries(res)) {
  if(key=='userId'){
    id=value;
  }
}
return id;
}

function dateCalculator(fc: FormControl): { [key: string]: boolean } | null {
  var date2 = new Date();
    var date1 = new Date(fc.value);
    var diff = Math.abs(date1.getTime() - date2.getTime());
    var diffDays = Math.ceil(diff / (1000 * 3600 * 24)); 
    if(diffDays>=0&&diffDays<=7){
      return null;
    }
    return {'age':true};
}


